//
//  ViewController.swift
//  webview
//
//  Created by 203a09 on 2022/04/29.
//

import UIKit
import WebKit

class ViewController: UIViewController,WKNavigationDelegate {
    @IBOutlet var txtUrl: UITextField!
    @IBOutlet var myWebView: WKWebView!
    @IBOutlet var myActivityIndicator: UIActivityIndicatorView!
    //url의 인수를 통해 웹 페이지의 주소를 전달받아 웹 페이지를 보여줌
    func loadWebPage(_ url: String){
        let myUrl = URL(string: url)
        let myRequset = URLRequest(url: myUrl!)
        myWebView.load(myRequset)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myWebView.navigationDelegate = self
        loadWebPage("http://www.nate.com")// 앱 실행 시 초기 홈페이지를 불러옴
        
    }
    func webView(_webView : WKWebView, didCommit navigatopn:WKNavigation){
        myActivityIndicator.startAnimating()
        myActivityIndicator.isHidden = false
        
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!){
        myActivityIndicator.stopAnimating()
        myActivityIndicator.isHidden = true
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!,withError error : Error){
        myActivityIndicator.stopAnimating()
        myActivityIndicator.isHidden = true
    }
    //"http://" 문자열이 없을 경우 자동으로 삽입
    func checkUrl(_ url: String) -> String {
        var strUrl = url
        let flag = strUrl.hasPrefix("http://")
        if !flag{
            strUrl = "http://" + strUrl
        }
        return strUrl
    }
    //텍스트 필드에 적힌 주소로 웹 뷰 로딩
    @IBAction func btnGotoUrl(_ sender: UIButton) {
        let myUrl = checkUrl(txtUrl.text!)
        txtUrl.text = ""
        loadWebPage(myUrl)
    }
    //[구글]버튼을 클릭하면 구글 링크로 들어가짐
    @IBAction func btnGoSite1(_ sender: UIButton) {
        loadWebPage("http://www.google.co.kr")
    }
    //[네이버]버튼을 클릭하면 구글 링크로 들어가짐
    @IBAction func btnGoSite2(_ sender: UIButton) {
        loadWebPage("http://www.naver.com")
    }
    //[Youtube]버튼을 클릭하면 구글 링크로 들어가짐
    @IBAction func btnLoadHtmlString(_ sender: UIButton) {
       loadWebPage("http://www.youtube.com")
    }
    //[자주찾는채널]버튼을 클릭하면 구글 링크로 들어가짐
    @IBAction func btnLoadHtmlFile(_ sender: UIButton) {
        loadWebPage("https://www.youtube.com/c/ZakTa")
    }
    @IBAction func btnStop(_ sender: UIBarButtonItem) {
        myWebView.stopLoading() //웹 페이지의 로딩을 중지
    }
    @IBAction func btnReload(_ sender: UIBarButtonItem) {
        myWebView.reload() //웹 페이지를 재로딩
    }
    @IBAction func btnGoBack(_ sender: UIBarButtonItem) {
        myWebView.goBack() //이전 웹 페이지로 중지
    }
    @IBAction func btnGoForward(_ sender: UIBarButtonItem) {
        myWebView.goForward() //다음 웹 페이지로 이동
    }
    

}

